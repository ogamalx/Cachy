# CachyOS Kernel in GitHub Codespaces (x86_64)

## Use
1. Put these files at the root of your repo.
2. Open the repo on GitHub → **Code → Create codespace on main**.
3. After the container builds, run in the Codespace terminal:
   ```bash
   sudo -u build bash -lc "~/build.sh"
   ```
4. When it says `DONE`, download files from `~/out`.

## Files
- `.devcontainer/devcontainer.json` — Forces x86_64 Arch container and runs `postCreate.sh`.
- `postCreate.sh` — Creates build user and installs toolchain.
- `build.sh` — Clones and builds `linux-cachyos-x86-64-v3` from AUR and copies packages to `~/out`.
